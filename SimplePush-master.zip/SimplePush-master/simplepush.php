<?php

// $deviceToken = '7ecc33301dc857599566c0e6efd27308a2e1529225cbd37acf12c36643cdc903';
$deviceToken ='03d72a91c063578acb103b18cb95adbf81cd81992af104676550221bbd7869c3';

$message = 'iPad!';
$body['action'] = 'call';
$body['env'] = 'production';
$body['fcm_token'] = "03d72a91c063578acb103b18cb95adbf81cd81992af104676550221bbd7869c3";
$body['handle'] = "787";
$body['name'] = "Dr. Luffy PHP Server";
$body['source_token'] = "android-cEE5_u55QpWgvu3lnleoSb:APA91bFFt6qbcQjAWXYC7LjYyBopqe48lM4orVerQcj8_SoEXntqrv2NOyprL-OuiS2DfyIRKjTaI9Z1mtOlZRhdWSbL-ALKWu66G4lezTPxL35Ck6QicqRiBVOdGTbSYT_MMiwureMq";
$body['to'] = "Ahmed Ibrahim";
$body['uuid'] = "d50df4b6-10ac-5503-bf61-715626d7ca1a";

//Server stuff
$passphrase = '';
$ctx = stream_context_create();
stream_context_set_option($ctx, 'ssl', 'local_cert', 'VOIP.pem');
stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

$fp = stream_socket_client(
	'ssl://gateway.push.apple.com:2195', $err,
	// 'ssl://gateway.sandbox.push.apple.com:2195', $err,
	$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

if (!$fp)
	exit("Failed to connect: $err $errstr" . PHP_EOL);

echo 'Connected to APNS' . PHP_EOL;

$payload = json_encode($body);

// Build the binary notification
$msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;

// Send it to the server
$result = fwrite($fp, $msg, strlen($msg));

if (!$result)
	echo 'Message not delivered' . PHP_EOL;
else
	echo 'Message successfully delivered' . PHP_EOL;

fclose($fp);
    
?>
