# SimplePush

To create a push, export both the private an public key as server_certificates_bundle[_sandbox].p12

    openssl pkcs12 -in Certificates.p12 -out VOIP.pem -nodes -clcerts

On Enter Password press enter key

To create a push, modify simplepush.php to the correct token and cert. To make a push simply type:

    php simplepush.php
